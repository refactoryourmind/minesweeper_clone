package minesweeper;

import java.awt.Color;

@Author(
		   author = "James Ostrander",
		   date = "5/15/2012",
		   lastModified = "8/6/2012"
		)

@SuppressWarnings("serial")
public final class SafeCell extends FirstCell 
{
	
	public SafeCell(MinePanel setParentGame, int setPosX, int setPosY)
	{
		super(setParentGame, setPosX, setPosY);
	}
	
	@Override
	public void reveal()
	{
		super.myRevealed = true;
		setBackground(Color.WHITE);
		super.unflag();
		super.myParentGame.decrementSafeCellsUnrevealed();
		System.out.println("Revealing cell:" + this.getClass().toString() + "  X: " + super.myPosX + "  Y: " + super.myPosY + "  Remaining safecells: " + super.myParentGame.getSafeCellsUnrevealed());
		
		int mineCounter = 0;
		
		//Checking in all 8 directions around the current tile.
		if(myPosX+1 < myParentGame.getSizeX())                                                //First, confirm we're not going out of bounds.
			if(super.myParentGame.getCellAt(super.myPosX+1, super.myPosY) instanceof MineCell)   //Next, see if we're looking at a mine cell.
				mineCounter++;                                                              //If so, increment our mineCounter
		
		if(myPosX-1 >= 0)
			if(super.myParentGame.getCellAt(super.myPosX-1, super.myPosY) instanceof MineCell)	
				mineCounter++;
		
		if(myPosY+1 < myParentGame.getSizeY())
			if(super.myParentGame.getCellAt(super.myPosX, super.myPosY+1) instanceof MineCell)	
				mineCounter++;
		
		if(myPosY-1 >= 0)
			if(super.myParentGame.getCellAt(super.myPosX, super.myPosY-1) instanceof MineCell)	
				mineCounter++;
		
		if(myPosX+1 < myParentGame.getSizeX() && myPosY+1 < myParentGame.getSizeY())
			if(super.myParentGame.getCellAt(super.myPosX+1, super.myPosY+1) instanceof MineCell)	
				mineCounter++;
		
		if(myPosX-1 >= 0 && myPosY-1 >= 0)
			if(super.myParentGame.getCellAt(super.myPosX-1, super.myPosY-1) instanceof MineCell)	
				mineCounter++;
		
		if(myPosX-1 >= 0 && myPosY+1 < myParentGame.getSizeY())
			if(super.myParentGame.getCellAt(super.myPosX-1, super.myPosY+1) instanceof MineCell)	
				mineCounter++;
		
		if(myPosX+1 < myParentGame.getSizeX() && myPosY-1 >= 0)
			if(super.myParentGame.getCellAt(super.myPosX+1, super.myPosY-1) instanceof MineCell)	
				mineCounter++;

		
		//Let's set our number to the proper color...
		switch(mineCounter)
		{
		case 0: 
			this.setText("");
			break;
		case 1: 
			this.setForeground(Color.BLUE);
			this.setText("1");
			break;
		case 2: 
			this.setForeground(new Color(0, 175, 128));
			this.setText("2");
			break;
		case 3: 
			this.setForeground(Color.RED);
			this.setText("3");
			break;
		case 4: 
			this.setForeground(Color.MAGENTA);
			this.setText("4");
			break;
		case 5: 
			this.setForeground(Color.ORANGE);
			this.setText("5");
			break;
		case 6: 
			this.setForeground(Color.CYAN);
			this.setText("6");
			break;
		case 7: 
			this.setForeground(Color.PINK);
			this.setText("7");
			break;
		case 8: 
			this.setForeground(Color.DARK_GRAY);
			this.setText("8");
			break;
		default: 
			this.setText("!");
			break;
		}
		
		
		if(mineCounter == 0)
		{		
			if(myPosX+1 < myParentGame.getSizeX())                                                     //As above, confirm we're not out of bounds.
				if(super.myParentGame.getCellAt(super.myPosX+1, super.myPosY).getIsRevealed() == false)	 //This time confirm that the cell isn't already revealed
					super.myParentGame.getCellAt(super.myPosX+1, super.myPosY).reveal();                  //Reveal that cell. Recursion! :D
			
			if(myPosX-1 >= 0)
				if(super.myParentGame.getCellAt(super.myPosX-1, super.myPosY).getIsRevealed() == false)	
					super.myParentGame.getCellAt(super.myPosX-1, super.myPosY).reveal();
			
			if(myPosY+1 < myParentGame.getSizeY())
				if(super.myParentGame.getCellAt(super.myPosX, super.myPosY+1).getIsRevealed() == false)
					super.myParentGame.getCellAt(super.myPosX, super.myPosY+1).reveal();
			
			if(myPosY-1 >= 0)
				if(super.myParentGame.getCellAt(super.myPosX, super.myPosY-1).getIsRevealed() == false)
					super.myParentGame.getCellAt(super.myPosX, super.myPosY-1).reveal();
			
			if(myPosX+1 < myParentGame.getSizeX() && myPosY+1 < myParentGame.getSizeY())
				if(super.myParentGame.getCellAt(super.myPosX+1, super.myPosY+1).getIsRevealed() == false)
					super.myParentGame.getCellAt(super.myPosX+1, super.myPosY+1).reveal();
			
			if(myPosX-1 >= 0 && myPosY-1 >= 0)
				if(super.myParentGame.getCellAt(super.myPosX-1, super.myPosY-1).getIsRevealed() == false)
					super.myParentGame.getCellAt(super.myPosX-1, super.myPosY-1).reveal();
			
			if(myPosX-1 >= 0 && myPosY+1 < myParentGame.getSizeY())
				if(super.myParentGame.getCellAt(super.myPosX-1, super.myPosY+1).getIsRevealed() == false)
					super.myParentGame.getCellAt(super.myPosX-1, super.myPosY+1).reveal();
			
			if(myPosX+1 < myParentGame.getSizeX() && myPosY-1 >= 0)
				if(super.myParentGame.getCellAt(super.myPosX+1, super.myPosY-1).getIsRevealed() == false)
					super.myParentGame.getCellAt(super.myPosX+1, super.myPosY-1).reveal();
		}
		
		if(super.myParentGame.getSafeCellsUnrevealed() == 0)
		{
			myParentGame.setVictory();
		}
	}

	
	
}
