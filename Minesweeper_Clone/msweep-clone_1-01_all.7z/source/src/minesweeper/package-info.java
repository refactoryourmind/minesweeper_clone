package minesweeper;

@interface Author {
	   String author();
	   String date();
	   String lastModified();
	}